```
mkdir font-patcher
cd font-patcher
curl -OL https://github.com/ryanoasis/nerd-fonts/releases/download/v2.3.1/FontPatcher.zip
unzip FontPatcher.zip

cat readme.md

fontforge --script ./font-patcher --complete /System/Library/Fonts/Monaco.ttf
```
