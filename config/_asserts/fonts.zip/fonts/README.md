Patch apple's Monaco font:

```bash
mkdir in out && cp /System/Library/Fonts/Monaco.ttf in/"
docker run -v \$(pwd)/in:/in -v \$(pwd)/out:/out nerdfonts/patcher --complete --removeligatures --makegroups"
```
