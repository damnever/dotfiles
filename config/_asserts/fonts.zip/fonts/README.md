```
git clone --filter=blob:none --sparse git@github.com:ryanoasis/nerd-fonts
cd nerd-fonts
git sparse-checkout add src/glyphs
git sparse-checkout add src/svgs

python3 font-patcher -c --glyphdir src/glyphs/ /System/Library/Fonts/Monaco.ttf
```
